# Ubersicht Mac OS Version

An ubersicht widget to display macOS name, version, build and uptime on the desktop. The Build number can be hidden and the widget is themable. Four themes are included: mono, paper, dark and color.

Includes releases from MacOS Yosemite to MacOS Sonoma.

![](screenshot.png)

## Installation

Copy contents of root folder into Ubersicht widget folder. It is possible, You'll need to restart Ubersicht for new widget to be detected.